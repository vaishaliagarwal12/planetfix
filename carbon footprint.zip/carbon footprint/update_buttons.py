import os
import re

base_dir = r"c:\Users\Udit Mishra\Music\carbon footprint"

file_map = {
    "landing_page_winning_dark_mode": "index.html",
    "login_winning_dark_mode": "login.html",
    "dashboard_winning_dark_mode": "dashboard.html",
    "calculator_winning_dark_mode": "calculator.html",
    "profile_winning_dark_mode": "profile.html",
    "rewards_winning_dark_mode": "rewards.html",
}

def update_buttons(filepath):
    if not os.path.exists(filepath):
        return
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Map button text to onclick location
    button_mapping = [
        (r'Home', 'dashboard.html'),
        (r'Impact', 'calculator.html'),
        (r'Shop', 'rewards.html'),
        (r'Profile', 'profile.html'),
    ]

    for pattern, target in button_mapping:
        # Match <button ...> ... Text ... </button>
        # Add onclick if not present
        def replace_button(m):
            btn_tag = m.group(1)
            inner_html = m.group(2)
            if 'onclick=' not in btn_tag:
                btn_tag = btn_tag.replace('<button', f'<button onclick="window.location.href=\'{target}\'"')
            return f'{btn_tag}{inner_html}</button>'

        # We need a robust regex for this
        content = re.sub(
            r'(<button[^>]*>)((?:(?!</button>).)*>'+pattern+'<.*?)</button>',
            replace_button,
            content,
            flags=re.IGNORECASE | re.DOTALL
        )
        
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)

for target_name in file_map.values():
    target_path = os.path.join(base_dir, target_name)
    update_buttons(target_path)

print("Updated mobile buttons.")

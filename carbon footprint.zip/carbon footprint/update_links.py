import os
import re
import shutil

base_dir = r"c:\Users\Udit Mishra\Music\carbon footprint"

file_map = {
    "landing_page_winning_dark_mode": "index.html",
    "login_winning_dark_mode": "login.html",
    "dashboard_winning_dark_mode": "dashboard.html",
    "calculator_winning_dark_mode": "calculator.html",
    "profile_winning_dark_mode": "profile.html",
    "rewards_winning_dark_mode": "rewards.html",
}

for d, target_name in file_map.items():
    source_path = os.path.join(base_dir, d, "code.html")
    target_path = os.path.join(base_dir, target_name)
    if os.path.exists(source_path):
        print(f"Moving {source_path} to {target_path}")
        shutil.copy(source_path, target_path)

def update_file(filepath):
    if not os.path.exists(filepath):
        return
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Map link text (or part of it) to the target html file
    link_mapping = [
        (r'Dashboard|Home', 'dashboard.html'),
        (r'Marketplace|Carbon Credits|Shop', 'rewards.html'),
        (r'Impact', 'calculator.html'),
        (r'Profile|Settings', 'profile.html'),
    ]

    for pattern, target in link_mapping:
        # Regex to find <a href="...">...Text...</a>
        # This will match <a ...> ... Text ... </a> and replace the href
        content = re.sub(
            r'(<a[^>]*href=")([^"]*)("[^>]*>)(?:(?:(?!</a>).)*)(?:' + pattern + r')(?:(?:(?!</a>).)*)</a>',
            lambda m: m.group(0).replace(m.group(1) + m.group(2) + m.group(3), m.group(1) + target + m.group(3)),
            content,
            flags=re.IGNORECASE | re.DOTALL
        )
        
    # Specifically for Connect Wallet or Enter the Ecosystem buttons to go to login or dashboard
    content = content.replace('Connect Wallet', '<a href="login.html" style="text-decoration:none; color:inherit;">Connect Wallet</a>')
    content = content.replace('Enter the Ecosystem', '<a href="dashboard.html" style="text-decoration:none; color:inherit;">Enter the Ecosystem</a>')
    content = content.replace('Start Restoration', '<a href="login.html" style="text-decoration:none; color:inherit;">Start Restoration</a>')

    # Re-write file
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"Updated links in {filepath}")

for target_name in file_map.values():
    target_path = os.path.join(base_dir, target_name)
    update_file(target_path)

print("Done linking pages.")

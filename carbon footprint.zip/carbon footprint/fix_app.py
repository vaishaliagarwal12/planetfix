import os
import re

base_dir = r"c:\Users\Udit Mishra\Music\carbon footprint"

files_with_nav = ["dashboard.html", "profile.html", "rewards.html"]

new_nav = """<nav class="md:hidden fixed bottom-0 left-0 w-full glass-card h-20 px-8 flex justify-between items-center z-50">
<a href="dashboard.html" class="flex flex-col items-center gap-1 text-outline hover:text-primary transition-colors">
<span class="material-symbols-outlined">dashboard</span>
<span class="text-[10px] font-bold">Home</span>
</a>
<a href="calculator.html" class="flex flex-col items-center gap-1 text-outline hover:text-primary transition-colors">
<span class="material-symbols-outlined">eco</span>
<span class="text-[10px] font-bold">Impact</span>
</a>
<button class="w-14 h-14 bg-primary text-on-primary rounded-full shadow-[0_0_20px_rgba(105,246,184,0.4)] flex items-center justify-center mb-10 border-4 border-background">
<span class="material-symbols-outlined">qr_code_scanner</span>
</button>
<a href="rewards.html" class="flex flex-col items-center gap-1 text-outline hover:text-primary transition-colors">
<span class="material-symbols-outlined">shopping_cart</span>
<span class="text-[10px] font-bold">Shop</span>
</a>
<a href="profile.html" class="flex flex-col items-center gap-1 text-outline hover:text-primary transition-colors">
<span class="material-symbols-outlined">person</span>
<span class="text-[10px] font-bold">Profile</span>
</a>
</nav>"""

# Fix mobile nav in dashboard, profile, rewards
for filename in files_with_nav:
    filepath = os.path.join(base_dir, filename)
    if os.path.exists(filepath):
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Replace the entire old nav block
        content = re.sub(
            r'<nav class="md:hidden fixed bottom-0.*?</nav>',
            new_nav,
            content,
            flags=re.DOTALL
        )
        
        # Also highlight the current page in the nav by adding text-primary and fill-icon
        # Find the <a href="filename" ...> and replace text-outline with text-primary, and add fill-icon to the span
        page_link = f'href="{filename}"'
        if page_link in content:
            # We only modify the block inside the newly inserted nav, so we can just do string replacements on new_nav
            pass # Actually, it's easier to just do it generally
            
        # Let's manually highlight the current page in the nav
        if filename == "dashboard.html":
            content = content.replace('<a href="dashboard.html" class="flex flex-col items-center gap-1 text-outline', '<a href="dashboard.html" class="flex flex-col items-center gap-1 text-primary')
            content = content.replace('<span class="material-symbols-outlined">dashboard</span>', '<span class="material-symbols-outlined fill-icon">dashboard</span>')
        elif filename == "profile.html":
            content = content.replace('<a href="profile.html" class="flex flex-col items-center gap-1 text-outline', '<a href="profile.html" class="flex flex-col items-center gap-1 text-primary')
            content = content.replace('<span class="material-symbols-outlined">person</span>', '<span class="material-symbols-outlined fill-icon">person</span>')
        elif filename == "rewards.html":
            content = content.replace('<a href="rewards.html" class="flex flex-col items-center gap-1 text-outline', '<a href="rewards.html" class="flex flex-col items-center gap-1 text-primary')
            content = content.replace('<span class="material-symbols-outlined">shopping_cart</span>', '<span class="material-symbols-outlined fill-icon">shopping_cart</span>')

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"Fixed mobile nav in {filename}")

# Fix calculator sidebar link
calc_path = os.path.join(base_dir, "calculator.html")
if os.path.exists(calc_path):
    with open(calc_path, 'r', encoding='utf-8') as f:
        calc_content = f.read()
    
    # Replace profile.html with rewards.html for Carbon Credits
    calc_content = calc_content.replace(
        '<a class="flex items-center gap-4 bg-primary/10 text-primary rounded-full mx-4 px-6 py-3 shadow-[inset_0_0_12px_rgba(105,246,184,0.2)] uppercase text-xs font-bold tracking-wide transition-all duration-300" href="profile.html">\n<span class="material-symbols-outlined" data-icon="eco" style="font-variation-settings: \'FILL\' 1;">eco</span> Carbon Credits\n            </a>',
        '<a class="flex items-center gap-4 text-slate-500 px-8 py-3 hover:text-primary-dim hover:translate-x-1 transition-all duration-200 uppercase text-xs font-bold tracking-wide" href="rewards.html">\n<span class="material-symbols-outlined" data-icon="eco">eco</span> Carbon Credits\n            </a>'
    )
    
    # Wait, the styling in calculator for Carbon Credits was active (bg-primary/10). But Calculator is the Impact page!
    # So Impact should be active, not Carbon Credits.
    # But wait, does calculator.html have "Impact" in its sidebar? It doesn't seem to have "Impact".
    # Wait, in the sidebar: Dashboard, Carbon Credits, Team Analytics, Offset Strategy, Settings.
    # Impact might be "Offset Strategy" or something else.
    # Either way, let's just make the link to rewards.html correct.
    calc_content = re.sub(
        r'<a [^>]*href="profile\.html"[^>]*>\s*<span[^>]*>eco</span>\s*Carbon Credits\s*</a>',
        r'<a class="flex items-center gap-4 text-slate-500 px-8 py-3 hover:text-primary-dim hover:translate-x-1 transition-all duration-200 uppercase text-xs font-bold tracking-wide" href="rewards.html">\n<span class="material-symbols-outlined" data-icon="eco">eco</span> Carbon Credits\n</a>',
        calc_content,
        flags=re.IGNORECASE | re.DOTALL
    )

    with open(calc_path, 'w', encoding='utf-8') as f:
        f.write(calc_content)
    print("Fixed calculator.html links")
